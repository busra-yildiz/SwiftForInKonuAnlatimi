import UIKit

//1 ile 3 arasındaki sayıları döngüye çağıran kod
for x in 1...3{
    print ("Döngü 1 :\(x)")
}




//10 ile 20 arasında 5er artış olan sayıları yazdıran kod

for a in stride(from: 10, through: 20, by: 5) {
    print ("Döngü 2 : \(a)")
   
}



//20 ile 10 arasında 5er azalış olan sayıları yazdıran kod

for b in stride(from: 20, through: 10, by: -5) {
    print ("Döngü 3 :\(b)")
}
